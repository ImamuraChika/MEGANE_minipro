package hanpuku1;

import hanpuku1.Game;

public class SystemTest {
	public static void main(String[] args) {
		Game game = new Game();
		game.start();
	}
}
