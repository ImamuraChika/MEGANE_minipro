package hanpuku1;

public enum Mark {
	CIRCLE, CROSS, NONE
}